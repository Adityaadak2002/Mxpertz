import React from 'react';
import Menu from './Component/Menu';
import Pagefirst from './Component/Pagefirst';
import Secondepage from './Component/Secondepage';
import Thirdpage from './Component/Thirdpage';


function App() {
  return (
    <div>
      <Menu />
      <Pagefirst/>
      <Secondepage/>
      <Thirdpage/>
    </div>
  );
}

export default App;
