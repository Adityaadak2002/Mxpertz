import React from 'react';
import "./Menu.css";

function Menu() {
  return (
    <>
      <header>
        <div className="container">
          <div>Restaurant Landing Page</div>
          <nav className='nav'>
            <a href="#">Landing</a>
            <a href="#">Home</a>
            <a href="#">Gallery</a>
            <a href="#">Shop</a>
            <a href="#">Blog</a>
            <a href="#">About</a>
            <a href="#">Team</a>
            <a href="#">Contact</a>
            <a href=""><i class="fa-solid fa-cart-shopping"></i></a>
          </nav>
        </div>
      </header>
    </>
  );
}

export default Menu;
