import React from "react";
import "./Pagefirst.css";

function Pagefirst() {
  return (
    <div className="page1">
      <p className="hedding">Only Quality Food</p>
      <p className="contain">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem quo
        debitis, cum sint iure sed animi quibusdam, nemo ullam iusto numquam
        voluptates exercitationem veritatis unde voluptatum possimus amet!
        Asperiores, repudiandae. Lorem ipsum dolor sit amet consectetur
        adipisicing elit. Tempore facere enim cum? Tenetur magni quia quaerat
        labore, nihil sequi a omnis voluptatem, molestias tempore non at. Dolor
        commodi ut quis.
      </p>
      <div class="contain">
        <div class="but">
          <button>VIEW MENU</button>
        </div>
        <div class="but2">
          <button>RESERVATION</button>
        </div>
      </div>
    </div>
  );
}

export default Pagefirst;
