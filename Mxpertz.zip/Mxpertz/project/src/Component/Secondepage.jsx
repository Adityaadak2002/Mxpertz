import React from 'react';
import "./Secondpage.css";

function Secondpage() {
  return (
    <>
      <div className='Secondpage'>
        <div className='contain2'>
          <p className='t'>Our Story</p>
          <p >Welcome To ROYAL</p>
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem sunt distinctio adipisci temporibus aliquam at esse delectus asperiores, modi ipsam ipsa in accusamus possimus quibusdam reprehenderit quos doloribus, rerum facere?</p>
        </div>
        <div className='imgpad'><img src="https://img.freepik.com/free-photo/burger-hamburger-cheeseburger_505751-3690.jpg?size=338&ext=jpg&ga=GA1.1.1448711260.1706745600&semt=sph" alt="" className='img2' /></div>
      </div>
    </>
  );
}

export default Secondpage;
