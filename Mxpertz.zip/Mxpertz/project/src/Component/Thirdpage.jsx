import React from 'react'
import "./Thirdpage.css"

function Thirdpage() {
  return (
    <>
    <div className='Third'>
    <p className=' p-1'>ONLY THE BEST</p>
    <p className='p'>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
    <p className='p'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro at cumque laborum fugit iure excepturi alias eligendi, voluptates dolor, ullam repellendus consequuntur ipsum omnis maxime rerum reprehenderit tempore quis assumenda?</p>
    <button className='VIEW'>VIEW ITEM</button>
    </div>
    </>
  )
}

export default Thirdpage
